--
-- PostgreSQL database dump
--

-- Dumped from database version 11.0
-- Dumped by pg_dump version 11.0

-- Started on 2018-10-26 17:54:11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- TOC entry 197 (class 1259 OID 16397)
-- Name: alumno; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.alumno (
    identificador integer NOT NULL,
    idpersona integer,
    legajo integer NOT NULL
);


ALTER TABLE public.alumno OWNER TO postgres;

--
-- TOC entry 198 (class 1259 OID 16409)
-- Name: carrera; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.carrera (
    identificador integer NOT NULL,
    nombre character varying(40) NOT NULL,
    descripcion character varying(250),
    fechadesde date NOT NULL,
    fechahasta date
);


ALTER TABLE public.carrera OWNER TO postgres;

--
-- TOC entry 199 (class 1259 OID 16414)
-- Name: curso; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.curso (
    identificador integer NOT NULL,
    idcarrera integer,
    nombre character varying(40) NOT NULL,
    descripcion character varying(250),
    cupomaximo smallint NOT NULL,
    anio smallint NOT NULL,
    iddocente integer
);


ALTER TABLE public.curso OWNER TO postgres;

--
-- TOC entry 205 (class 1259 OID 16467)
-- Name: docente; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.docente (
    identificador integer NOT NULL,
    nombre character varying(120)
);


ALTER TABLE public.docente OWNER TO postgres;

--
-- TOC entry 204 (class 1259 OID 16461)
-- Name: identificador; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.identificador
    START WITH 1
    INCREMENT BY 50
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.identificador OWNER TO postgres;

--
-- TOC entry 200 (class 1259 OID 16424)
-- Name: inscripciones_carrera; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.inscripciones_carrera (
    idalumno integer NOT NULL,
    idcarrera integer NOT NULL,
    fechainscripcion date NOT NULL
);


ALTER TABLE public.inscripciones_carrera OWNER TO postgres;

--
-- TOC entry 201 (class 1259 OID 16437)
-- Name: inscripciones_curso; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.inscripciones_curso (
    idalumno integer NOT NULL,
    idcurso integer NOT NULL,
    fechainscripcion date NOT NULL,
    nota smallint
);


ALTER TABLE public.inscripciones_curso OWNER TO postgres;

--
-- TOC entry 196 (class 1259 OID 16392)
-- Name: persona; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.persona (
    identificador integer NOT NULL,
    tipodoc character varying(5) NOT NULL,
    documento bigint NOT NULL,
    nombre character varying(40) NOT NULL,
    apellido character varying(40) NOT NULL,
    fechanac date NOT NULL,
    direccion character varying(200)
);


ALTER TABLE public.persona OWNER TO postgres;

--
-- TOC entry 203 (class 1259 OID 16452)
-- Name: teset; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.teset (
    id integer NOT NULL,
    nombre character varying
);


ALTER TABLE public.teset OWNER TO postgres;

--
-- TOC entry 202 (class 1259 OID 16450)
-- Name: teset_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.teset_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.teset_id_seq OWNER TO postgres;

--
-- TOC entry 2229 (class 0 OID 0)
-- Dependencies: 202
-- Name: teset_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.teset_id_seq OWNED BY public.teset.id;


--
-- TOC entry 2071 (class 2604 OID 16455)
-- Name: teset id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.teset ALTER COLUMN id SET DEFAULT nextval('public.teset_id_seq'::regclass);


--
-- TOC entry 2215 (class 0 OID 16397)
-- Dependencies: 197
-- Data for Name: alumno; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.alumno (identificador, idpersona, legajo) FROM stdin;
1	3	98734
2	4	9213
3	1	35839
4	5	36299
5	2	11009
6	6	98734
7	7	12345
\.


--
-- TOC entry 2216 (class 0 OID 16409)
-- Dependencies: 198
-- Data for Name: carrera; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.carrera (identificador, nombre, descripcion, fechadesde, fechahasta) FROM stdin;
1	Ingenieria en sistema de información	Carrera a fines a programación y desarrollo de software en general	1960-01-01	\N
2	Ingenieria civil	Carrera a fines a construcción, planificación y desarrollo de obras de desarrollo urbano	1980-01-01	\N
\.


--
-- TOC entry 2217 (class 0 OID 16414)
-- Dependencies: 199
-- Data for Name: curso; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.curso (identificador, idcarrera, nombre, descripcion, cupomaximo, anio, iddocente) FROM stdin;
6	2	Dibujo	Curso sobre dibujo de planos	10	2018	4
3	1	Java	Curso sobre el lenguaje de programación JAVA	10	2018	3
4	1	Base de datos-SQL	Curso sobre tipos de base de datos y consultas sql	10	2018	2
2	1	Diseño de sistemas	Curso sobre diseño de componentes de sistemas de software	10	2018	2
1	1	Análisis matemático	Curso sobre el desarrollo avanzado de matemáticas	5	2018	1
5	2	Fisica básica	Curso sobre fundamentos base de física	5	2018	1
\.


--
-- TOC entry 2223 (class 0 OID 16467)
-- Dependencies: 205
-- Data for Name: docente; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.docente (identificador, nombre) FROM stdin;
1	Florez Pepe
2	Elisa Vazquez
3	Roberto Frijoles
4	Moreno Lopez
\.


--
-- TOC entry 2218 (class 0 OID 16424)
-- Dependencies: 200
-- Data for Name: inscripciones_carrera; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.inscripciones_carrera (idalumno, idcarrera, fechainscripcion) FROM stdin;
1	1	2000-01-01
2	1	2003-01-01
3	1	2004-01-01
4	1	2001-01-01
5	2	2000-01-01
4	2	2000-01-01
\.


--
-- TOC entry 2219 (class 0 OID 16437)
-- Dependencies: 201
-- Data for Name: inscripciones_curso; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.inscripciones_curso (idalumno, idcurso, fechainscripcion, nota) FROM stdin;
1	1	2002-01-01	\N
1	3	2002-01-01	\N
2	1	2004-01-01	\N
2	3	2002-01-01	\N
2	4	2004-01-01	\N
3	1	2010-01-01	\N
3	3	2010-01-01	\N
4	1	2010-01-01	\N
5	3	2010-01-01	\N
5	4	2011-01-01	\N
4	4	2011-01-01	\N
2	5	2011-01-01	\N
2	6	2011-01-01	\N
1	2	2006-01-01	4
4	3	2010-01-01	4
4	3	2010-01-01	4
1	2	2018-10-26	\N
2	2	2018-10-26	\N
4	4	2018-10-26	\N
5	3	2018-10-26	\N
\.


--
-- TOC entry 2214 (class 0 OID 16392)
-- Dependencies: 196
-- Data for Name: persona; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.persona (identificador, tipodoc, documento, nombre, apellido, fechanac, direccion) FROM stdin;
1	DNI	31565839	Florencia	Maneiro	1985-06-28	\N
4	DNI	30999281	Franzo	Perez	1986-02-05	\N
6	DNI	24321422	Juan	Prez	1984-11-29	\N
3	DNI	24321422	Ian	Prez	1984-11-30	\N
7	DNI	5648945	Pepito	Florez	1985-10-08	Calle algo 431
2	DNI	31000123	Patricia Alejandra	Brumatti	1985-01-02	Calle falsa 12356
5	DNI	24112872	Leandro	Garcia	1988-01-02	Calle falsa2 564
\.


--
-- TOC entry 2221 (class 0 OID 16452)
-- Dependencies: 203
-- Data for Name: teset; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.teset (id, nombre) FROM stdin;
1	Juan
\.


--
-- TOC entry 2230 (class 0 OID 0)
-- Dependencies: 204
-- Name: identificador; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.identificador', 1, false);


--
-- TOC entry 2231 (class 0 OID 0)
-- Dependencies: 202
-- Name: teset_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.teset_id_seq', 1, true);


--
-- TOC entry 2075 (class 2606 OID 16403)
-- Name: alumno alumno_idpersona_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alumno
    ADD CONSTRAINT alumno_idpersona_key UNIQUE (idpersona);


--
-- TOC entry 2077 (class 2606 OID 16401)
-- Name: alumno alumno_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alumno
    ADD CONSTRAINT alumno_pkey PRIMARY KEY (identificador);


--
-- TOC entry 2079 (class 2606 OID 16413)
-- Name: carrera carrera_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.carrera
    ADD CONSTRAINT carrera_pkey PRIMARY KEY (identificador);


--
-- TOC entry 2081 (class 2606 OID 16418)
-- Name: curso curso_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.curso
    ADD CONSTRAINT curso_pkey PRIMARY KEY (identificador);


--
-- TOC entry 2085 (class 2606 OID 16474)
-- Name: docente docente_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.docente
    ADD CONSTRAINT docente_pkey PRIMARY KEY (identificador);


--
-- TOC entry 2083 (class 2606 OID 16460)
-- Name: teset id; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.teset
    ADD CONSTRAINT id PRIMARY KEY (id);


--
-- TOC entry 2073 (class 2606 OID 16396)
-- Name: persona persona_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.persona
    ADD CONSTRAINT persona_pkey PRIMARY KEY (identificador);


--
-- TOC entry 2086 (class 2606 OID 16404)
-- Name: alumno alumno_idpersona_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.alumno
    ADD CONSTRAINT alumno_idpersona_fkey FOREIGN KEY (idpersona) REFERENCES public.persona(identificador);


--
-- TOC entry 2087 (class 2606 OID 16419)
-- Name: curso curso_idcarrera_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.curso
    ADD CONSTRAINT curso_idcarrera_fkey FOREIGN KEY (idcarrera) REFERENCES public.carrera(identificador);


--
-- TOC entry 2088 (class 2606 OID 16475)
-- Name: curso curso_iddocente_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.curso
    ADD CONSTRAINT curso_iddocente_fkey FOREIGN KEY (iddocente) REFERENCES public.docente(identificador);


--
-- TOC entry 2089 (class 2606 OID 16427)
-- Name: inscripciones_carrera inscripciones_carrera_idalumno_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inscripciones_carrera
    ADD CONSTRAINT inscripciones_carrera_idalumno_fkey FOREIGN KEY (idalumno) REFERENCES public.alumno(identificador);


--
-- TOC entry 2090 (class 2606 OID 16432)
-- Name: inscripciones_carrera inscripciones_carrera_idcarrera_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inscripciones_carrera
    ADD CONSTRAINT inscripciones_carrera_idcarrera_fkey FOREIGN KEY (idcarrera) REFERENCES public.carrera(identificador);


--
-- TOC entry 2091 (class 2606 OID 16440)
-- Name: inscripciones_curso inscripciones_curso_idalumno_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inscripciones_curso
    ADD CONSTRAINT inscripciones_curso_idalumno_fkey FOREIGN KEY (idalumno) REFERENCES public.alumno(identificador);


--
-- TOC entry 2092 (class 2606 OID 16445)
-- Name: inscripciones_curso inscripciones_curso_idcurso_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inscripciones_curso
    ADD CONSTRAINT inscripciones_curso_idcurso_fkey FOREIGN KEY (idcurso) REFERENCES public.curso(identificador);


-- Completed on 2018-10-26 17:54:12

--
-- PostgreSQL database dump complete
--

