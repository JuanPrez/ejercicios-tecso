﻿--Realizar una consulta para consultar todos los alumnos existentes, mostrar: TipoDoc, Documento, Nombre, Apellido, Legajo.
SELECT P.Tipodoc as TipoDoc, P.documento as Documento, P.nombre as Nombre, P.apellido AS Apellido, A.legajo AS A 
FROM Alumno AS A
INNER JOIN Persona AS P ON A.idpersona = P.identificador;

--Realizar una consulta para consultar todas las carreras a la que un alumno esta inscripto, mostrar: Legajo, nombre, apellido, nombre carrera, fechainscripcioncarrera
--ordenado por legajo descendiente
SELECT A.legajo, P.nombre, P.apellido, C.nombre as "Nombre Carrera", I.fechainscripcion AS "Fecha Inscripcion Carrera"
FROM inscripciones_carrera AS I
INNER JOIN Carrera AS C ON C.identificador = I.idcarrera
INNER JOIN Alumno AS A ON A.identificador = I.idalumno
INNER JOIN Persona AS P ON A.idpersona = P.identificador
ORDER BY A.legajo DESC;

--- EJERCICIO 3 - COMPLEJIDAD MEDIA: 
--Realizar una consulta para consultar la cantidad de inscriptos por curso, mostrando: 
-- nombre carrera, nombre curso, cantidad inscriptos, cupo máximo por curso
SELECT C.nombre AS carrera, CS.nombre as curso, COUNT(I.idalumno) as Inscriptos, CS.cupomaximo 
FROM curso AS CS
INNER JOIN Carrera AS C ON C.identificador = CS.idcarrera
INNER JOIN inscripciones_curso AS I ON C.identificador = I.idcurso
GROUP BY C.nombre, CS.nombre, CS.cupomaximo;

--- EJERCICIO 4 - COMPLEJIDAD ALTA: 
SELECT T.* FROM 
(SELECT C.nombre AS carrera, CS.nombre as curso, COUNT(I.idalumno) as Inscriptos, CS.cupomaximo 
FROM curso AS CS
INNER JOIN carrera AS C ON C.identificador = CS.idcarrera
INNER JOIN inscripciones_curso AS I ON C.identificador = I.idcurso
GROUP BY C.nombre, CS.nombre, CS.cupomaximo) AS T
WHERE cupomaximo < inscriptos;

--- EJERCICIO 5 -  COMPLEJIDAD BAJA: 
-- actualizar todos las cursos que posean anio 2018 y cuyo cupo sea menor a 5, y actualizar el cupo de todos ellos a 10.

UPDATE Curso SET cupomaximo = 10 WHERE anio = 2018 AND cupomaximo < 5;

--- EJERCICIO 6 -  COMPLEJIDAD ALTA: 
-- actualizar todas las fechas de inscripcion a cursados que posean el siguiente error: 
-- la fecha de inscripcion al cursado de un alumno es menor a la fecha de inscripcion a la carrera. 
-- 
-- La nueva fecha que debe tener es la fecha del dia. Se puede hacer en dos pasos, primero
-- realizando la consulta y luego realizando el update manual

SELECT 
  CASE
    WHEN ICS.fechainscripcion < ICR.fechainscripcion 
    THEN 'Error'
    ELSE 'Valida'
  END 
  AS Validacion,
ICS.fechainscripcion AS "Fecha Inscripcion Curso", 
ICR.fechainscripcion AS "Fecha Inscripcion Carrera", 
ICS.idalumno AS idalumno,
P.apellido,
P.nombre,
C.nombre,
ICS.idcurso AS idcurso 
FROM inscripciones_curso AS ICS
INNER JOIN Alumno AS A ON A.identificador = ICS.idalumno
INNER JOIN Persona AS P ON A.idpersona = P.identificador
INNER JOIN curso AS C ON C.identificador = ICS.idcurso,
inscripciones_carrera AS ICR
ORDER BY Validacion;

UPDATE inscripciones_curso 
SET fechainscripcion = ?
WHERE idalumno = ? AND idcurso = ?;

--- EJERCICIO 7 - COMPLEJIDAD BAJA:  
--INSERTAR un nuevo registro de alumno con tus datos personales, (hacer todos inserts que considera necesario)

-- idPersona 
INSERT INTO persona VALUES ((SELECT (MAX(identificador)+1) FROM persona), 'DNI', 31330853, 'Juan', 'Prez', TO_DATE('30/11/1984', 'DD/MM/YYYY'));

-- idAlumno

INSERT INTO alumno VALUES ((SELECT (MAX(identificador)+1) FROM alumno), *idPersona*, 12345);

--- EJERCICIO 8 -  COMPLEJIDAD BAJA: 
-- si se desea comenzar a persistir de ahora en mas el dato de direccion de un alumno y considerando que este es un único cambio 
-- string de 200 caracteres.
-- Determine sobre que tabla seria mas conveniente persistir esta información y realizar la modificación de estructuras correspondientes.

ALTER TABLE public.persona DROP COLUMN direccion;
ALTER TABLE public.persona ADD COLUMN direccion character varying(200);
















