package ejercicios;
/**
 * Ejercicio: analizar la siguente clase y realizar las correcciones
 * necesarias para que compile  
 * @author examen
 *
 */
public class Ejercicio1 {
	
	  	int count1;
	    static int count2;  

	    public Ejercicio1() {
	    	count1 = 0;
	    	count2 ++;
	    }

	    public void incrementa1() {
	    	count1++;
	    }

	    public void incrementa2() {
	    	count2++;
	    }

	    public void incrementa() {
	    	count1++;
	    }

	    public static void main(String[] args) {
	    	int p = 9 / 2;
	    	int p2 = Math.round(9 / 2);
	    	
			System.out.println(p);
			System.out.println(p2);
	    }
}
