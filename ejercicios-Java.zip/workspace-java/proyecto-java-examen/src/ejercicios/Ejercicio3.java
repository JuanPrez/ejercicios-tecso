/**
 * 
 */
package ejercicios;

import java.text.SimpleDateFormat;

/**
 * A. Crear una clase Alumnno con los siguientes campos (con sus respectivos
 * getters, setters y constructor)
 * 
 * Persona Legajo - Integer
 * 
 * 
 * @author examen
 *
 */
public class Ejercicio3 {

	/**
	 * 
	 */
	public Ejercicio3() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception {
		Alumno haceMucho = new Alumno(new Persona(TipoDocumento.dni, 31330853, "Juan", "Prez",
				new SimpleDateFormat("yyyyMMdd").parse("19841130")), 12345);

	}

}
