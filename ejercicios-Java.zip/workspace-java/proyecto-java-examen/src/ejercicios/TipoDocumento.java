package ejercicios;

public enum TipoDocumento {
	dni,
	libretacivica
}
